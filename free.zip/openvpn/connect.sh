#!/bin/bash

MYIP=$(wget -qO- ipv4.icanhazip.com);


HOST='mysql1.blazingfast.io'
USER='cybertea_old'
PASS='jan022011'
DB='cybertea_old'
PORT='3306'

tm="$(date +%s)"
dt="$(date +'%Y-%m-%d %H:%M:%S')"
timestamp="$(date +'%FT%TZ')"


##mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "UPDATE bandwidth_logs SET bytes_received='$bytes_received',bytes_sent='$bytes_sent',time_out='$dt', status='offline' WHERE username='$common_name' AND status='online' AND category='vip' "

mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "UPDATE users SET is_active=0 , ipaddress='$MYIP' , lastlogin='$dt' WHERE user_name='$common_name' "
	