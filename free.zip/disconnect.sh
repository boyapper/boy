#!/bin/bash

HOST='mysql1.blazingfast.io'
USER='cybertea_kidlat'
PASS='jan022011'
DB='cybertea_kidlat'
PORT='3306'

mysql -u $USER -p$PASS -D $DB -h $HOST -sN -e "UPDATE users SET is_active=1 WHERE user_name='$common_name' "